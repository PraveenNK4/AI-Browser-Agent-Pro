"""
Chrome Frame Screenshot — Selenium Version (Windows-style, real favicon).

Usage:
    python test_chrome_frame_selenium.py
    python test_chrome_frame_selenium.py --url https://confluence.opentext.com
    python test_chrome_frame_selenium.py --url https://a.com --url https://b.com
    python test_chrome_frame_selenium.py --visible
"""
import argparse
import base64
import datetime
import os
import time
from urllib.parse import urlparse


def get_favicon_b64(driver) -> str:
    """Fetch the page favicon and return it as a base64 data URI.
    Uses the <link rel='icon'> tag first, falls back to /favicon.ico."""
    try:
        favicon_url = driver.execute_script("""
            const el = document.querySelector(
                "link[rel='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']"
            );
            return el ? el.href : null;
        """)
        if not favicon_url:
            parsed = urlparse(driver.current_url)
            favicon_url = f"{parsed.scheme}://{parsed.hostname}/favicon.ico"

        # Fetch the favicon bytes via JS fetch (same-origin or cached already)
        favicon_b64 = driver.execute_script("""
            async function go(url) {
                try {
                    const r = await fetch(url);
                    if (!r.ok) return null;
                    const buf = await r.arrayBuffer();
                    const bytes = new Uint8Array(buf);
                    let bin = '';
                    bytes.forEach(b => bin += String.fromCharCode(b));
                    return 'data:image/png;base64,' + btoa(bin);
                } catch { return null; }
            }
            return go(arguments[0]);
        """, favicon_url)

        if favicon_b64:
            return favicon_b64
    except Exception:
        pass
    return ""   # empty → fallback globe in HTML


def build_chrome_frame_html(
    page_png_b64: str,
    url: str,
    title: str,
    favicon_data_uri: str = "",
    is_secure: bool = True,
    page_width: int = 1280,
    page_height: int = 900,
    timestamp: str = "",
) -> str:
    hostname  = urlparse(url).hostname or url
    lock_col  = "#1a6e2e" if is_secure else "#b31412"
    lock_icon = "🔒" if is_secure else "🔓"
    ts_label  = timestamp or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tab_title = title[:30] + "…" if len(title) > 32 else title
    path_part = urlparse(url).path or "/"

    # Real favicon <img> or globe emoji fallback
    favicon_html = (
        f'<img src="{favicon_data_uri}" width="14" height="14" style="flex-shrink:0" onerror="this.replaceWith(\'🌐\')">'
        if favicon_data_uri else "🌐"
    )

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<style>
  html, body {{ overflow: hidden; }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Arial, sans-serif; }}
  body {{ background: #e8eaed; display: inline-flex; flex-direction: column; }}
  .window {{ display: flex; flex-direction: column;
             width: {page_width + 2}px;
             box-shadow: 0 4px 24px rgba(0,0,0,.4); border: 1px solid #999; }}

  /* Tab bar */
  .tabbar {{ background: #dee1e6; display: flex; align-items: flex-end;
             height: 38px; padding-left: 8px; flex-shrink: 0; }}
  .tab {{ background: #fff; height: 32px; padding: 0 8px;
          min-width: 160px; max-width: 220px;
          display: flex; align-items: center; gap: 5px;
          border-radius: 8px 8px 0 0; border: 1px solid #ccc; border-bottom: none;
          font-size: 12.5px; color: #3c4043; flex-shrink: 0; }}
  .tab-title {{ flex: 1; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }}
  .tab-x {{ color: #80868b; font-size: 11px; flex-shrink: 0;
             padding: 2px 4px; border-radius: 3px; }}
  .newtab {{ background: none; border: none; width: 28px; height: 28px; margin: 0 4px;
             font-size: 18px; color: #5f6368; align-self: center; cursor: pointer; }}

  /* Windows controls top-right */
  .wc {{ margin-left: auto; display: flex; height: 38px; align-self: flex-start; flex-shrink: 0; }}
  .wb {{ width: 46px; border: none; background: none; color: #3c4043;
         cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center; }}
  .wb:hover {{ background: rgba(0,0,0,.1); }}
  .wb.x:hover {{ background: #c42b1c; color: #fff; }}

  /* Address bar */
  .toolbar {{ background: #f1f3f4; height: 46px; display: flex; align-items: center;
              padding: 0 12px; gap: 8px; border-bottom: 1px solid #dadce0; flex-shrink: 0; }}
  .nb {{ width: 28px; height: 28px; border-radius: 50%; border: none; background: none;
         cursor: pointer; color: #5f6368; font-size: 15px;
         display: flex; align-items: center; justify-content: center; }}
  .nb.off {{ color: #bdc1c6; cursor: default; }}
  .omni {{ flex: 1; height: 32px; background: #fff; border-radius: 16px;
            display: flex; align-items: center; gap: 7px; padding: 0 14px;
            border: 1px solid #dadce0; }}
  .lock {{ font-size: 13px; color: {lock_col}; flex-shrink: 0; }}
  .addr {{ font-size: 13px; color: #202124; flex: 1;
           white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
  .scheme {{ color: #5f6368; }}

  /* Page */
  .page img {{ display: block; }}

  /* Minimal status bar */
  .status {{ background: #f8f9fa; height: 20px; display: flex; align-items: center;
             padding: 0 10px; font-size: 11px; color: #80868b;
             border-top: 1px solid #e8eaed; flex-shrink: 0; justify-content: space-between; }}
</style>
</head>
<body>
<div class="window">

  <div class="tabbar">
    <div class="tab">
      {favicon_html}
      <span class="tab-title">{tab_title}</span>
      <span class="tab-x">✕</span>
    </div>
    <button class="newtab">+</button>
    <div class="wc">
      <button class="wb">&#x2500;</button>
      <button class="wb">&#x25A1;</button>
      <button class="wb x">&#x2715;</button>
    </div>
  </div>

  <div class="toolbar">
    <button class="nb off">&#8592;</button>
    <button class="nb">&#8635;</button>
    <div class="omni">
      <span class="lock">{lock_icon}</span>
      <div class="addr"><span class="scheme">{urlparse(url).scheme}://</span>{hostname}{path_part}</div>
    </div>
    <button class="nb">&#8942;</button>
  </div>

  <div class="page">
    <img src="data:image/png;base64,{page_png_b64}" width="{page_width}" height="{page_height}">
  </div>

  <div class="status">
    <span>{url}</span>
    <span>Captured {ts_label}</span>
  </div>

</div>
</body>
</html>"""


def add_timestamp(img_bytes: bytes) -> bytes:
    """Append a dark bar with the current timestamp to the bottom of the image."""
    import io, datetime
    try:
        from PIL import Image, ImageDraw, ImageFont
        im = Image.open(io.BytesIO(img_bytes))
        BAR_H = 28
        out = Image.new("RGB", (im.width, im.height + BAR_H), (30, 31, 33))
        out.paste(im, (0, 0))
        draw = ImageDraw.Draw(out)
        try:
            font = ImageFont.truetype("arial.ttf", 13)
        except Exception:
            font = ImageFont.load_default()
        
        ts_str = datetime.datetime.now().strftime("Captured: %Y-%m-%d  %H:%M:%S")
        draw.rectangle([0, im.height, im.width, im.height + BAR_H], fill=(20, 21, 24))
        draw.text((10, im.height + 6), ts_str, fill=(180, 180, 180), font=font)
        
        buf = io.BytesIO()
        out.save(buf, "PNG")
        return buf.getvalue()
    except ImportError:
        print("[!] PIL not installed, skipping timestamp overlay (pip install Pillow)")
        return img_bytes
    except Exception as e:
        print(f"[!] Timestamp overlay failed: {e}")
        return img_bytes


def capture_with_chrome_frame(driver, url: str, out_dir: str) -> str:
    print(f"\n[*] -> {url}")
    driver.get(url)
    time.sleep(2)

    current_url = driver.current_url
    page_title  = driver.title or urlparse(url).hostname
    is_secure   = current_url.startswith("https://")

    target_w, target_h = 1280, 900
    driver.set_window_size(target_w, target_h + 150)
    time.sleep(0.3)

    favicon_uri = get_favicon_b64(driver)
    page_b64    = base64.b64encode(driver.get_screenshot_as_png()).decode()

    ts   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    html = build_chrome_frame_html(
        page_png_b64=page_b64,
        url=current_url,
        title=page_title,
        favicon_data_uri=favicon_uri,
        is_secure=is_secure,
        page_width=target_w,
        page_height=target_h,
        timestamp=ts,
    )

    driver.get(f"data:text/html;base64,{base64.b64encode(html.encode()).decode()}")

    # Width is fixed by CSS — only measure height dynamically
    driver.set_window_size(target_w + 40, 2000)   # wide enough; height auto-measured
    time.sleep(0.6)

    frame_h = driver.execute_script("""
        const el = document.querySelector('.window');
        if (!el) return document.documentElement.scrollHeight;
        return Math.ceil(el.getBoundingClientRect().height) + 4;
    """)
    driver.set_window_size(target_w + 4, int(frame_h) + 4)
    time.sleep(0.3)

    frame_png = driver.get_screenshot_as_png()
    frame_png = add_timestamp(frame_png)
    slug    = (urlparse(url).hostname or "page").replace(".", "_")
    ts_file = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path    = os.path.join(out_dir, f"framed_{slug}_{ts_file}.png")
    with open(path, "wb") as f:
        f.write(frame_png)
    print(f"[+] Saved: {path}  ({len(frame_png):,} bytes)")
    return path


def main():
    parser = argparse.ArgumentParser(description="Windows Chrome frame screenshot (Selenium)")
    parser.add_argument("--url", action="append", dest="urls", metavar="URL")
    parser.add_argument("--visible", action="store_true")
    args = parser.parse_args()

    urls = args.urls or ["https://otcs.g143-dev.opentext.cloud/cs/cs.exe?otdsauth=no-sso", "https://en.wikipedia.org"]

    _script_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir     = os.path.join(_script_dir, "screenshots")
    os.makedirs(out_dir, exist_ok=True)

    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    opts = Options()
    if not args.visible:
        opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1280,1100")
    opts.add_argument("--force-device-scale-factor=1")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")

    print(f"[*] Launching Chrome ({'visible' if args.visible else 'headless'})...")
    driver = webdriver.Chrome(options=opts)
    try:
        for url in urls:
            capture_with_chrome_frame(driver, url, out_dir)
    finally:
        driver.quit()

    print(f"\n[+] Screenshots saved to: {out_dir}")


if __name__ == "__main__":
    main()
