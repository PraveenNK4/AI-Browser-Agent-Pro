"""
Full native browser screenshot on Linux using Xvfb + mss.
Works in headless server environments (PuTTY/SSH) — no real display needed.

The virtual display gives Chrome a real GPU-composited window to render into,
so the captured screenshot includes the full browser UI: address bar, tabs,
lock icon — exactly like Win32 PrintWindow on Windows.

Requirements:
    sudo apt install xvfb
    pip install pyvirtualdisplay mss Pillow playwright
    playwright install chromium
    playwright install-deps

Usage:
    python test_linux_printwindow.py                             # YouTube + Wikipedia
    python test_linux_printwindow.py --url https://example.com  # any URL
    python test_linux_printwindow.py --driver selenium          # use Selenium instead
"""
import argparse
import asyncio
import datetime
import os
import sys
import time
from io import BytesIO
from urllib.parse import urlparse


# ─────────────────────────────────────────────────────────────────────────────
# Virtual display helper
# ─────────────────────────────────────────────────────────────────────────────

def start_virtual_display(width: int = 1920, height: int = 1080):
    """Start an Xvfb virtual display. Returns the Display object."""
    try:
        from pyvirtualdisplay import Display
        display = Display(visible=False, size=(width, height), color_depth=24)
        display.start()
        print(f"[xvfb] Virtual display started: {width}x{height} on DISPLAY={os.environ.get('DISPLAY', '?')}")
        return display
    except ImportError:
        sys.exit("❌  pyvirtualdisplay not installed. Run: pip install pyvirtualdisplay")
    except Exception as e:
        sys.exit(f"❌  Could not start Xvfb virtual display: {e}\n"
                 f"    Is Xvfb installed?  sudo apt install xvfb")


def capture_full_screen() -> bytes:
    """Capture the entire virtual display as a PNG using mss."""
    try:
        import mss
        import mss.tools
    except ImportError:
        sys.exit("❌  mss not installed. Run: pip install mss")

    with mss.mss() as sct:
        # monitors[0] = all screens combined; monitors[1] = first screen
        monitor = sct.monitors[1]
        raw = sct.grab(monitor)
        return mss.tools.to_png(raw.rgb, raw.size)


def add_timestamp(img_bytes: bytes) -> bytes:
    """Append a dark bar with the current timestamp to the bottom of the image."""
    import io, datetime
    try:
        from PIL import Image, ImageDraw, ImageFont
        im = Image.open(io.BytesIO(img_bytes))
        BAR_H = 28
        out = Image.new("RGB", (im.width, im.height + BAR_H), (30, 31, 33))
        out.paste(im, (0, 0))
        draw = ImageDraw.Draw(out)
        try:
            font = ImageFont.truetype("arial.ttf", 13)
        except Exception:
            font = ImageFont.load_default()
        
        ts_str = datetime.datetime.now().strftime("Captured: %Y-%m-%d  %H:%M:%S")
        draw.rectangle([0, im.height, im.width, im.height + BAR_H], fill=(20, 21, 24))
        draw.text((10, im.height + 6), ts_str, fill=(180, 180, 180), font=font)
        
        buf = io.BytesIO()
        out.save(buf, "PNG")
        return buf.getvalue()
    except ImportError:
        print("[!] PIL not installed, skipping timestamp overlay (pip install Pillow)")
        return img_bytes
    except Exception as e:
        print(f"[!] Timestamp overlay failed: {e}")
        return img_bytes


def save_png(data: bytes, url: str, prefix: str, out_dir: str) -> str:
    data = add_timestamp(data)
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = (urlparse(url).hostname or "page").replace(".", "_")
    path = os.path.join(out_dir, f"{prefix}_{slug}_{ts}.png")
    with open(path, "wb") as f:
        f.write(data)
    print(f"[+] Saved: {path}  ({len(data):,} bytes)")
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Playwright version
# ─────────────────────────────────────────────────────────────────────────────

async def run_playwright(urls: list[str], out_dir: str):
    from playwright.async_api import async_playwright

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,   # MUST be headed — headless has no browser UI to capture
            args=[
                "--window-size=1920,1080",
                "--force-device-scale-factor=1",
                "--disable-gpu",              # no GPU on most Linux servers
                "--no-sandbox",               # required in many server environments
                "--disable-dev-shm-usage",    # /dev/shm too small in containers
            ],
        )
        context = await browser.new_context(viewport={"width": 1920, "height": 1040})
        page    = await context.new_page()

        for url in urls:
            print(f"\n[*] → {url}")
            await page.goto(url, timeout=60_000)
            await page.wait_for_load_state("networkidle")
            await page.wait_for_timeout(2_000)   # let Chrome compositor settle

            data = capture_full_screen()          # captures the Xvfb virtual screen
            save_png(data, url, "playwright_linux", out_dir)

        await browser.close()


# ─────────────────────────────────────────────────────────────────────────────
# Selenium version
# ─────────────────────────────────────────────────────────────────────────────

def run_selenium(urls: list[str], out_dir: str):
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
    except ImportError:
        sys.exit("❌  selenium not installed. Run: pip install selenium")

    opts = Options()
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--force-device-scale-factor=1")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    # NOTE: do NOT add --headless — we need a real window for the browser UI

    driver = webdriver.Chrome(options=opts)
    try:
        for url in urls:
            print(f"\n[*] → {url}")
            driver.get(url)
            time.sleep(3)                                 # wait for compositor paint

            data = capture_full_screen()
            save_png(data, url, "selenium_linux", out_dir)
    finally:
        driver.quit()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Full native browser screenshot via Xvfb + mss (Linux/PuTTY/SSH)"
    )
    parser.add_argument("--url", action="append", dest="urls", metavar="URL",
                        help="URL to capture (repeatable). Default: YouTube + Wikipedia")
    parser.add_argument("--driver", choices=["playwright", "selenium"],
                        default="selenium",
                        help="Browser driver to use (default: playwright)")
    parser.add_argument("--width",  type=int, default=1920, help="Virtual display width")
    parser.add_argument("--height", type=int, default=1080, help="Virtual display height")
    args = parser.parse_args()

    urls = args.urls or [
        "https://www.youtube.com",
        "https://en.wikipedia.org",
    ]

    _script_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir     = os.path.join(_script_dir, "screenshots")
    os.makedirs(out_dir, exist_ok=True)

    # Start the virtual framebuffer (Xvfb) — this replaces the real monitor
    display = start_virtual_display(args.width, args.height)

    try:
        if args.driver == "selenium":
            run_selenium(urls, out_dir)
        else:
            asyncio.run(run_playwright(urls, out_dir))
    finally:
        display.stop()
        print("\n[xvfb] Virtual display stopped")

    print("\n✅ Done — full browser screenshots captured via Xvfb + mss")


if __name__ == "__main__":
    main()
