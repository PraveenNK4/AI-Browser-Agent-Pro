# test_printwindow.py — Playwright + Win32 PrintWindow (Windows)

## What Does This Script Do?

It **silently opens Chrome off-screen**, visits one or more websites, and takes
a **genuine OS-level full-browser screenshot** — including the address bar,
🔒 padlock, tabs, and Chrome toolbar — things a normal screenshot tool cannot capture.

The result is a pixel-perfect PNG showing the **real Chrome window**, indistinguishable
from a manual screenshot. Saved to `screenshots/` automatically.

---

## Who Should Use This?

Anyone who needs **automated, auditable visual proof** of what a browser looks like —
especially the security/SSL indicator — without a person manually taking a screenshot.

| Use Case | Why This Matters |
|---|---|
| SSL/TLS compliance evidence | Proves the padlock is real, not faked |
| Security audit reports | Shows the full address bar and HTTPS status |
| Automated screenshot testing | Runs without a monitor or logged-in session |
| Regression capture | Consistent 1920×1080 screenshots every time |

---

## Quick Start

```bash
pip install playwright pillow psutil
playwright install chromium

# Default: YouTube + Wikipedia
python test_printwindow.py

# Any URL
python test_printwindow.py --url https://confluence.opentext.com

# Multiple URLs
python test_printwindow.py --url https://site1.com --url https://site2.com
```

> **To make Chrome visible while it runs:** comment out the `WINDOW_POSITION` line at the top of the script (one line change, no other edits needed).

---

## How It Works — Step by Step

```
┌─────────────────────────────────────────────────────────────┐
│  1. Launch Chrome HEADED at position (-3000, -3000)         │
│     → Off-screen: Chrome renders a real window but          │
│       it's 3000px to the left — invisible to the user       │
│                                                             │
│  2. Playwright navigates to the URL                         │
│     → Waits for networkidle (page fully loaded)             │
│     → Extra 2s wait for GPU compositor to finish painting   │
│                                                             │
│  3. Find Chrome's window handle (HWND) via Win32 API        │
│     → Enumerates all windows, filters by Chrome class name  │
│       (Chrome_WidgetWin_1) AND our specific PID family      │
│                                                             │
│  4. Force-resize the window to exactly 1920×1080            │
│     → Off-screen windows get shrunk by Windows DWM;         │
│       SetWindowPos restores the full size                   │
│                                                             │
│  5. Call Win32 PrintWindow(hwnd, memDC, PW_RENDERFULLCONTENT│
│     → Asks Windows to paint the window into a memory bitmap │
│       This works even off-screen (no screen access needed)  │
│                                                             │
│  6. Convert bitmap → PIL Image → PNG                        │
│     → BGRA buffer → Pillow → saved to screenshots/          │
└─────────────────────────────────────────────────────────────┘
```

---

## Libraries Used & Why

| Library | Why Used |
|---|---|
| **Playwright** (`playwright.async_api`) | Async browser automation with async/await. Supports `networkidle` wait — knows when the page is truly done loading. More reliable than a fixed sleep. |
| **ctypes / ctypes.wintypes** | Python's built-in interface to Windows DLLs. Used to call `user32.dll` (PrintWindow, EnumWindows, SetWindowPos) and `gdi32.dll` (CreateCompatibleDC, GetDIBits). No external dependencies. |
| **Pillow (PIL)** | Converts the raw BGRA pixel buffer from GDI into a proper PNG file. |
| **psutil** | Traverses the Chrome process tree (parent PID → child PIDs) so we can filter `EnumWindows` to only find *our* Chrome window, not other Chrome instances on the same machine. |

### Why not just use `page.screenshot()`?

`page.screenshot()` only captures the **web page content** — it has no access to
the browser chrome (address bar, tabs, padlock). The lock icon, HTTPS indicator,
and tab title exist in Chrome's native UI layer, which only the OS can render.
`PrintWindow` captures exactly what Windows has composited for that window — every pixel.

### Why `PW_RENDERFULLCONTENT = 2`?

Modern Chrome uses GPU-accelerated compositing (DirectComposition on Windows).
Without this flag, `PrintWindow` asks the window's WM_PRINT handler to paint,
but Chrome's compositor content stays blank. Flag value `2` forces Chrome to flush
its compositor content into the GDI device context before returning.

### Why negative window position (`-3000, -3000`)?

Chrome must be **headed** (not headless) for `PrintWindow` to work — it needs a
real GPU-composited window. But we don't want it visible. Placing it at `(-3000, -3000)`
puts it far off-screen. The DWM still composites it; `PrintWindow` still captures it.

---

## Output

```
tests/printwindow/
└── screenshots/
    └── playwright_en_wikipedia_org_20260303_094212.png
```

**Filename format:** `playwright_{hostname}_{YYYYMMDD}_{HHMMSS}.png`

---

## Requirements

| Requirement | Version |
|---|---|
| Python | 3.10+ |
| playwright | any recent |
| Pillow | any recent |
| psutil | any recent |
| OS | **Windows only** (Win32 API) |

---

## Visibility Toggle

```python
# Top of script — one line controls everything:
WINDOW_POSITION = (-3000, -3000)   # ← comment this to show Chrome on screen
```
