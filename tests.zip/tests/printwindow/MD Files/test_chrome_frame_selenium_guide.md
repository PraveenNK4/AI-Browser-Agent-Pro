# test_chrome_frame_selenium.py — Chrome Frame Screenshot (All Platforms)

## What Does This Script Do?

It takes a **headless page screenshot** and wraps it in a **pixel-accurate,
Windows-style Chrome browser frame** — complete with a real tab (showing the page
favicon and title), address bar with the real URL and 🔒 padlock, and
minimize/maximize/close buttons in the top-right corner.

The result looks exactly like a real Chrome browser window screenshot, but works
**fully headless** — no display, no Xvfb, no X server needed.

---

## Who Should Use This?

Use this script when you need **browser-framed screenshots** but cannot use the
`PrintWindow` method (e.g., on Linux/WSL, in CI/CD pipelines, or Docker containers).

| Scenario | Recommendation |
|---|---|
| Windows with a real display | ✅ Use `test_printwindow.py` or `test_selenium_printwindow.py` for the authentic real capture |
| Linux / WSL / Docker / CI | ✅ Use this script — works headless, no Xvfb needed |
| Need real favicon in tab | ✅ This script fetches and embeds the real site favicon |
| Need the actual lock-icon native chrome | Use `PrintWindow` variants on Windows |

---

## Quick Start

```bash
pip install selenium

# Default: Google + Wikipedia
python test_chrome_frame_selenium.py

# Any URL
python test_chrome_frame_selenium.py --url https://confluence.opentext.com

# Multiple URLs
python test_chrome_frame_selenium.py --url https://site1.com --url https://site2.com

# Run Chrome visibly (not headless)
python test_chrome_frame_selenium.py --url https://site1.com --visible
```

---

## How It Works — Step by Step

```
┌───────────────────────────────────────────────────────────────────┐
│  1. Selenium launches Chrome in headless=new mode                 │
│     → Chrome renders pages but has no visible window             │
│                                                                   │
│  2. Navigate to the target URL and wait 2 seconds                │
│     → Collect: page title, current URL, HTTPS status             │
│                                                                   │
│  3. Fetch the real favicon via JavaScript                        │
│     → Queries <link rel="icon"> from DOM                         │
│     → Falls back to /favicon.ico if no <link> tag found          │
│     → Fetches favicon bytes via JS fetch() API                   │
│     → Base64-encodes them for embedding                          │
│                                                                   │
│  4. Take a page screenshot via Selenium                          │
│     → driver.get_screenshot_as_png() → base64-encoded            │
│                                                                   │
│  5. Build the Chrome frame HTML template                         │
│     → Windows-style: tab bar at top, ─ □ ✕ controls top-right  │
│     → Embeds favicon as <img src="data:image/png;base64,...">    │
│     → Embeds page screenshot as <img src="data:image/png;...">   │
│     → Real URL, real title, real HTTPS lock color in address bar │
│                                                                   │
│  6. Load the composite HTML via a data: URI in the same driver   │
│     → driver.get("data:text/html;base64,{html_base64}")          │
│                                                                   │
│  7. Measure the exact rendered element size via JS               │
│     → First loads in 3000×2000 window (not constrained)         │
│     → getBoundingClientRect() on .window reads exact px size     │
│     → Resizes driver window to exact size + 20px margin          │
│                                                                   │
│  8. Screenshot the composite → saved to screenshots/             │
└───────────────────────────────────────────────────────────────────┘
```

---

## Libraries Used & Why

| Library | Why Used |
|---|---|
| **Selenium 4** | Browser automation to navigate pages, execute JavaScript, and take screenshots — all in headless mode. No display required. |
| **base64** (stdlib) | Encode the page PNG and the frame HTML into `data:` URIs so they can be loaded in the browser without writing temp files to disk. |
| **urllib.parse** (stdlib) | Parses URLs to extract hostname and path for display in the address bar. |
| **datetime** (stdlib) | Generates timestamp-based filenames so no two screenshots overwrite each other. |

### Why No Pillow?

Unlike the `PrintWindow` scripts, this approach never touches raw pixel buffers.
The browser itself renders the composite HTML and Selenium screenshots it — so
Pillow isn't needed.

### The Favicon Fetch Strategy

```python
# Priority order:
1. <link rel="icon"> / <link rel="shortcut icon"> / <link rel="apple-touch-icon">
2. Fall back to /{hostname}/favicon.ico
3. If both fail → show 🌐 emoji
```

The fetch is done via JavaScript `fetch()` inside the headless browser —
this uses the browser's existing session/cookies, so it works for authenticated
pages too.

### Why `data:` URIs Instead of Temp Files?

Loading the composite via `data:text/html;base64,...` keeps everything in-process —
no disk I/O for temp HTML files, no file path issues on Windows vs Linux,
and no cleanup needed. The composite renders in the same Chrome instance.

### Why Load in a 3000×2000 Window First?

When measuring the rendered frame size with `getBoundingClientRect()`, the window
must be large enough that the `.window` element is never constrained by the viewport.
If the window is too narrow, the element clips and the measurement is wrong —
the `✕` close button ends up cropped. Loading in a huge window first guarantees
the true intrinsic size is measured.

---

## Requirements

| Requirement | Notes |
|---|---|
| Python 3.10+ | |
| selenium 4+ | ChromeDriver auto-managed |
| OS | **Windows, Linux, macOS, WSL, Docker** — any platform |

> Unlike the `PrintWindow` scripts, this requires **no Win32 API** and
> works anywhere Chrome can run in headless mode.
