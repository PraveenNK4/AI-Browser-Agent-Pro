# test_linux_printwindow.py — Full Browser Screenshot on Linux/WSL/SSH

## What Does This Script Do?

It runs Chrome in **headed mode inside a virtual display** (Xvfb), then captures
the **full virtual screen** using `mss` — giving you a screenshot that includes
the browser address bar, tabs, padlock icon, and all browser chrome.

This is the **Linux equivalent** of the Windows `PrintWindow` approach. Works
on remote servers accessed via PuTTY/SSH where there is no physical monitor.

---

## Who Should Use This?

| Scenario | Use This? |
|---|---|
| Running on a Linux server via PuTTY/SSH | ✅ Yes |
| Running on a Linux VM (no desktop) | ✅ Yes |
| Running on a machine with a real display | ✅ Yes (use `--visible` to see Chrome) |
---

## Quick Start

```bash
# 1. Install system dependencies
sudo apt install xvfb

# 2. Install Python packages
pip install pyvirtualdisplay mss Pillow selenium

# 3. Run (Selenium is the default driver)
python3 test_linux_printwindow.py --url https://confluence.opentext.com

# Use Playwright instead
python3 test_linux_printwindow.py --url https://confluence.opentext.com --driver playwright

# Custom screen resolution
python3 test_linux_printwindow.py --width 1920 --height 1080

# Multiple URLs
python3 test_linux_printwindow.py --url https://site1.com --url https://site2.com
```

---

## How It Works — Step by Step

```
┌───────────────────────────────────────────────────────────────────────┐
│  1. pyvirtualdisplay starts Xvfb (X Virtual Framebuffer)              │
│     → Creates a fake screen in RAM (e.g., 1920×1080)                  │
│     → Sets DISPLAY=:99 (or auto-assigned)                             │
│     → Any process that writes to this display goes into RAM           │   
│                                                                       │
│  2. Chrome launches in headed mode (headless=False)                   │
│     → Chrome renders to the Xvfb virtual screen like a real display   │
│     → Full browser UI is composited: address bar, tabs, lock icon     │
│                                                                       │
│  3. Navigate to the URL and wait for load                             │
│     → 3 seconds for the compositor to finish painting                 │
│                                                                       │
│  4. mss captures the entire virtual screen (monitors[1])              │
│     → Reads raw RGBA pixel data from the X framebuffer                │
│     → Converts to PNG bytes                                           │
│                                                                       │
│  5. PNG saved to screenshots/                                         │
│                                                                       │
│  6. pyvirtualdisplay.stop() — Xvfb process is killed                  │
└───────────────────────────────────────────────────────────────────────┘
```

---

## Libraries Used & Why

| Library | Why Used |
|---|---|
| **pyvirtualdisplay** | Python wrapper around Xvfb. Starts and stops the virtual X11 display automatically, sets `DISPLAY` env var, and cleans up on exit. Avoids manually running `Xvfb :99 &` in shell. |
| **Xvfb** (system package) | The actual virtual X11 framebuffer. Creates an in-memory display that Chrome can render to, just like a real monitor. Required because `mss` can only capture real/virtual X11 displays — not headless Chrome's internal buffer. |
| **mss** | Multi-Screen-Shot library. Directly reads pixel data from the X11 framebuffer without needing a real screen, screenshot utility, or subprocess. Faster than `scrot` or `xwd` and works in Python natively. |
| **Pillow (PIL)** | Used by `mss.tools.to_png()` internally to encode the RGBA pixel buffer to PNG. |
| **Selenium 4** (default) | Browser automation. Simpler dependency than Playwright — just `pip install selenium`. ChromeDriver auto-managed. |
| **Playwright** (optional) | Alternative driver with smarter `networkidle` wait. Requires `playwright install chromium` and `playwright install-deps`. |

### Why `mss` Instead of `scrot` or `xwd`?

| Tool | Requires Screen | Works in Python | Speed |
|---|---|---|---|
| `mss` | No (reads X11 buffer directly) | ✅ Native library | Fast |
| `scrot` | No | ❌ Subprocess | Moderate |
| `xwd` | No | ❌ Subprocess + convert | Slow |
| `gnome-screenshot` | Yes | ❌ Subprocess | N/A |

### Why Headed Chrome Instead of Headless?

In headless mode, Chrome renders only the page content — no browser UI (no address bar,
no tabs, no lock icon). To capture those elements, Chrome **must** render a real window.
Xvfb provides the virtual monitor that Chrome needs, making `headless=False` possible
on a server with no physical display.

### Extra Chrome Flags for Linux Servers

```python
--disable-gpu         # No GPU on most servers; prevents Chrome from crashing
--no-sandbox          # Required in server environments (SELinux, containers)
--disable-dev-shm-usage  # /dev/shm is often limited in containers; avoids crash
```

---

## Requirements

| Requirement | Notes |
|---|---|
| Python 3.10+ | |
| pyvirtualdisplay | Python wrapper for Xvfb |
| mss | Screen capture from X11 framebuffer |
| Pillow | Used internally by mss |
| selenium 4+ | Default driver |
| playwright (optional) | Alternative driver |
| xvfb | `sudo apt install xvfb` |
| OS | **Linux / WSL only** |
