# test_selenium_printwindow.py — Selenium + Win32 PrintWindow (Windows)

## What Does This Script Do?

It **silently opens Chrome off-screen**, visits one or more websites, and takes
a **genuine OS-level full-browser screenshot** — including the address bar,
🔒 padlock, tabs, and Chrome toolbar — using Selenium for browser control and
the Windows `PrintWindow` API for the actual capture.

The result is a pixel-perfect PNG showing the **real Chrome window**, saved to `screenshots/`.

---

## Who Should Use This?

Anyone who needs auditable full-browser screenshots from an automated script.
Prefer this version if your project **already uses Selenium** or you need simpler setup
(no `playwright install` step required).

| Use Case | Why |
|---|---|
| SSL/padlock evidence | Real lock icon visible in address bar |
| Enterprise environments | Selenium is widely supported in corporate setups |
| Scripted compliance capture | Runs unattended, no monitor needed |

---

## Quick Start

```bash
pip install selenium pillow psutil

# Default: YouTube + Wikipedia
python test_selenium_printwindow.py

# Any URL
python test_selenium_printwindow.py --url https://confluence.opentext.com

# Multiple URLs
python test_selenium_printwindow.py --url https://site1.com --url https://site2.com
```

> **To make Chrome visible:** comment out the `WINDOW_POSITION` line at the top of the script.

---

## How It Works — Step by Step

```
┌─────────────────────────────────────────────────────────────┐
│  1. Launch Chrome HEADED at position (-3000, -3000)         │
│     → Off-screen: visible to Windows, invisible to user     │
│                                                             │
│  2. Selenium navigates to the URL                           │
│     → driver.get(url) + 3-second sleep for compositor paint │
│                                                             │
│  3. Find Chrome PID from the driver                         │
│     → driver.service.process.pid = chromedriver PID         │
│     → psutil finds Chrome child process from chromedriver   │
│                                                             │
│  4. Find Chrome's HWND (window handle) via Win32            │
│     → EnumWindows scans all open windows                    │
│     → Filters by class "Chrome_WidgetWin_1" AND our PID     │
│     → Picks the largest matching window                     │
│                                                             │
│  5. Force-resize to 1920×1080 via SetWindowPos              │
│     → Off-screen windows shrink; this restores full size    │
│                                                             │
│  6. PrintWindow(hwnd, memDC, PW_RENDERFULLCONTENT)          │
│     → Windows paints the GPU-composited window to bitmap    │
│     → GetDIBits reads pixel data as BGRA buffer             │
│                                                             │
│  7. PIL converts BGRA → RGB → PNG → saved to screenshots/   │
└─────────────────────────────────────────────────────────────┘
```

---

## Libraries Used & Why

| Library | Why Used |
|---|---|
| **Selenium 4** (`selenium.webdriver`) | Industry-standard browser driver. Works through ChromeDriver as a middleman. ChromeDriver version is auto-matched to installed Chrome in Selenium 4. Simpler dep chain than Playwright. |
| **ctypes / ctypes.wintypes** | Built-in Python interface to Windows DLLs. Calls `user32.PrintWindow`, `user32.EnumWindows`, `user32.SetWindowPos`, and `gdi32.GetDIBits` with no extra installs. |
| **Pillow (PIL)** | Converts raw BGRA pixel buffer from GDI into a portable PNG. Chosen for its simple API and universal format support. |
| **psutil** | Walks the process tree from ChromeDriver PID → Chrome PID → all child renderer PIDs. Essential for multi-instance safety — ensures we find our own Chrome window and not another user's. |

### Selenium vs Playwright (for this use case)

| | Selenium | Playwright |
|---|---|---|
| Setup | `pip install selenium` only | `pip install playwright` + `playwright install chromium` |
| Wait strategy | Fixed `time.sleep(3)` | Smart `networkidle` wait |
| PID access | `driver.service.process.pid` | `browser.process.pid` |
| Speed | Slightly slower | Slightly faster |
| Enterprise support | ✅ Widely established | ✅ Growing adoption |

Both produce identical output — choose based on your team's tooling preference.

---

## Visibility Toggle

```python
# Top of script — one line controls everything:
WINDOW_POSITION = (-3000, -3000)   # ← comment this to show Chrome on screen
```

When commented out, `globals().get("WINDOW_POSITION", (0, 0))` returns `(0, 0)`,
so Chrome launches at the top-left corner of your screen.

---

## Output

```
tests/printwindow/
└── screenshots/
    └── selenium_en_wikipedia_org_20260303_094212.png
```

**Filename format:** `selenium_{hostname}_{YYYYMMDD}_{HHMMSS}.png`

---

## Requirements

| Requirement | Notes |
|---|---|
| Python 3.10+ | |
| selenium 4+ | ChromeDriver auto-managed |
| Pillow | Image conversion |
| psutil | Process tree traversal |
| OS | **Windows only** (Win32 API) |
