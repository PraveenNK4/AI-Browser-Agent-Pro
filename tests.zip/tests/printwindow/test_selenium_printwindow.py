"""
POC: Real OS-level full-browser screenshot via Win32 PrintWindow + Selenium.

Works even when Chrome is off-screen — captures the FULL native window including
the address bar, tabs, lock icon and all browser chrome.

Usage:
    python test_selenium_printwindow.py                              # default: YouTube + Wikipedia
    python test_selenium_printwindow.py --url https://example.com   # custom URL
"""
import argparse
import ctypes
import ctypes.wintypes
import os
import time
from io import BytesIO

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# ── DPI awareness — must be set BEFORE any Win32 calls ───────────────────────
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

# Comment out this line to make Chrome visible on screen:
WINDOW_POSITION = (-3000, -3000)


# ─────────────────────────────────────────────────────────────────────────────
# Win32 helpers
# ─────────────────────────────────────────────────────────────────────────────

def capture_window_screenshot(hwnd: int) -> bytes:
    """Capture a window's full content via Win32 PrintWindow. Returns PNG bytes.

    Falls back progressively: PW_RENDERFULLCONTENT → basic → BitBlt.
    """
    from PIL import Image

    PW_RENDERFULLCONTENT = 2
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32

    rect = ctypes.wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    width  = rect.right  - rect.left
    height = rect.bottom - rect.top
    if width <= 0 or height <= 0:
        raise RuntimeError(f"Window has invalid size: {width}x{height}")
    print(f"[win32] Window rect: {width}x{height} at ({rect.left},{rect.top})")

    hwnd_dc = user32.GetWindowDC(hwnd)
    mem_dc  = gdi32.CreateCompatibleDC(hwnd_dc)
    bitmap  = gdi32.CreateCompatibleBitmap(hwnd_dc, width, height)
    old_bmp = gdi32.SelectObject(mem_dc, bitmap)

    ok = user32.PrintWindow(hwnd, mem_dc, PW_RENDERFULLCONTENT)
    if not ok:
        print("[win32] PW_RENDERFULLCONTENT failed → basic mode")
        ok = user32.PrintWindow(hwnd, mem_dc, 0)
    if not ok:
        print("[win32] PrintWindow failed → BitBlt fallback")
        gdi32.BitBlt(mem_dc, 0, 0, width, height, hwnd_dc, 0, 0, 0x00CC0020)

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [
            ("biSize",          ctypes.c_uint32),
            ("biWidth",         ctypes.c_int32),
            ("biHeight",        ctypes.c_int32),
            ("biPlanes",        ctypes.c_uint16),
            ("biBitCount",      ctypes.c_uint16),
            ("biCompression",   ctypes.c_uint32),
            ("biSizeImage",     ctypes.c_uint32),
            ("biXPelsPerMeter", ctypes.c_int32),
            ("biYPelsPerMeter", ctypes.c_int32),
            ("biClrUsed",       ctypes.c_uint32),
            ("biClrImportant",  ctypes.c_uint32),
        ]

    bmi = BITMAPINFOHEADER()
    bmi.biSize        = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth       = width
    bmi.biHeight      = -height   # negative = top-down DIB
    bmi.biPlanes      = 1
    bmi.biBitCount    = 32
    bmi.biCompression = 0         # BI_RGB

    buf = ctypes.create_string_buffer(width * height * 4)
    gdi32.GetDIBits(mem_dc, bitmap, 0, height, buf, ctypes.byref(bmi), 0)

    gdi32.SelectObject(mem_dc, old_bmp)
    gdi32.DeleteObject(bitmap)
    gdi32.DeleteDC(mem_dc)
    user32.ReleaseDC(hwnd, hwnd_dc)

    img = Image.frombuffer("RGBA", (width, height), buf, "raw", "BGRA", 0, 1)
    out = BytesIO()
    img.convert("RGB").save(out, "PNG")
    return out.getvalue()


def find_chrome_hwnd(pids: set, timeout: float = 10.0) -> int:
    """Return the HWND of the largest Chrome_WidgetWin_1 owned by *pids*."""
    user32 = ctypes.windll.user32
    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    found: list[tuple[int, int]] = []

    def _cb(hwnd, _):
        cls = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, cls, 256)
        if cls.value != "Chrome_WidgetWin_1":
            return True
        pid = ctypes.wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pids and pid.value not in pids:
            return True
        rect = ctypes.wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        w = rect.right - rect.left
        h = rect.bottom - rect.top
        if w > 200 and h > 200:
            found.append((hwnd, w * h))
        return True

    cb = WNDENUMPROC(_cb)
    deadline = time.time() + timeout
    while time.time() < deadline:
        found.clear()
        user32.EnumWindows(cb, 0)
        if found:
            hwnd = max(found, key=lambda x: x[1])[0]
            title = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(hwnd, title, 512)
            print(f"[win32] Chrome HWND={hwnd} '{title.value[:60]}'")
            return hwnd
        time.sleep(0.5)
    raise RuntimeError("Chrome window not found within timeout")


def resize_window(hwnd: int, width: int = 1920, height: int = 1080, x: int = -3000, y: int = -3000):
    """Restore and force-resize a window to exact pixel dimensions."""
    user32 = ctypes.windll.user32
    user32.ShowWindow(hwnd, 9)          # SW_RESTORE
    time.sleep(0.3)
    user32.SetWindowPos(hwnd, 0, x, y, width, height, 0x0004)  # SWP_NOZORDER
    time.sleep(0.4)
    rect = ctypes.wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    print(f"[win32] Window resized to {rect.right-rect.left}x{rect.bottom-rect.top}")


def get_chrome_pid_from_driver(driver) -> int:
    """Get the real Chrome browser PID (not chromedriver) from a Selenium driver."""
    import psutil

    # chromedriver PID → find a Chrome child process
    cd_pid = driver.service.process.pid
    print(f"[*] chromedriver PID: {cd_pid}")
    try:
        for child in psutil.Process(cd_pid).children(recursive=True):
            if "chrome" in (child.name() or "").lower():
                print(f"[*] Chrome browser PID: {child.pid}")
                return child.pid
    except Exception:
        pass
    print(f"[*] Falling back to chromedriver PID: {cd_pid}")
    return cd_pid


def build_pid_family(root_pid: int) -> set[int]:
    """Return root PID + all its child PIDs."""
    import psutil
    pids = {root_pid}
    try:
        for child in psutil.Process(root_pid).children(recursive=True):
            pids.add(child.pid)
    except Exception:
        pass
    return pids


def add_timestamp(img_bytes: bytes) -> bytes:
    """Append a dark bar with the current timestamp to the bottom of the image."""
    import io, datetime
    try:
        from PIL import Image, ImageDraw, ImageFont
        im = Image.open(io.BytesIO(img_bytes))
        BAR_H = 28
        out = Image.new("RGB", (im.width, im.height + BAR_H), (30, 31, 33))
        out.paste(im, (0, 0))
        draw = ImageDraw.Draw(out)
        try:
            font = ImageFont.truetype("arial.ttf", 13)
        except Exception:
            font = ImageFont.load_default()
        
        ts_str = datetime.datetime.now().strftime("Captured: %Y-%m-%d  %H:%M:%S")
        draw.rectangle([0, im.height, im.width, im.height + BAR_H], fill=(20, 21, 24))
        draw.text((10, im.height + 6), ts_str, fill=(180, 180, 180), font=font)
        
        buf = io.BytesIO()
        out.save(buf, "PNG")
        return buf.getvalue()
    except ImportError:
        print("[!] PIL not installed, skipping timestamp overlay (pip install Pillow)")
        return img_bytes
    except Exception as e:
        print(f"[!] Timestamp overlay failed: {e}")
        return img_bytes

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def capture_url(driver, hwnd: int, url: str, filename: str, out_dir: str):
    """Navigate to *url*, wait for render, capture via PrintWindow, save PNG."""
    print(f"\n[*] → {url}")
    driver.get(url)
    time.sleep(3)          # wait for Chrome compositor to fully paint
    data = capture_window_screenshot(hwnd)
    data = add_timestamp(data)
    path = os.path.join(out_dir, filename)
    with open(path, "wb") as f:
        f.write(data)
    print(f"[+] Saved: {path}  ({len(data):,} bytes)")


def main(urls: list[str]):
    import datetime
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir     = os.path.join(_script_dir, "screenshots")
    os.makedirs(out_dir, exist_ok=True)

    opts = Options()
    _pos = globals().get("WINDOW_POSITION", (0, 0))
    opts.add_argument(f"--window-position={_pos[0]},{_pos[1]}")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--force-device-scale-factor=1")
    opts.add_argument("--disable-search-engine-choice-screen")
    # NOTE: do NOT add --headless — PrintWindow needs a real GPU-composited window

    print("[*] Launching Chrome (headed, off-screen)...")
    driver = webdriver.Chrome(options=opts)

    try:
        chrome_pid = get_chrome_pid_from_driver(driver)
        pids       = build_pid_family(chrome_pid)
        print(f"[*] Tracking {len(pids)} Chrome PIDs")

        # Navigate to first URL so the window exists, then find + resize it
        driver.get(urls[0])
        time.sleep(2)
        hwnd = find_chrome_hwnd(pids)
        resize_window(hwnd, 1920, 1080, x=_pos[0], y=_pos[1])

        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        for i, url in enumerate(urls, 1):
            from urllib.parse import urlparse
            slug = urlparse(url).hostname.replace(".", "_") if url else f"page{i}"
            capture_url(driver, hwnd, url, f"selenium_{slug}_{ts}.png", out_dir)

    finally:
        driver.quit()

    print("\n✅ Done — REAL OS-level Chrome screenshots via Selenium + Win32 PrintWindow")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Capture real Chrome screenshots via Win32 PrintWindow (Selenium)")
    parser.add_argument("--url", action="append", dest="urls",
                        metavar="URL", help="URL to capture (repeatable). Default: YouTube + Wikipedia")
    args = parser.parse_args()
    target_urls = args.urls or [
        "https://www.youtube.com",
        "https://en.wikipedia.org",
    ]
    main(target_urls)
