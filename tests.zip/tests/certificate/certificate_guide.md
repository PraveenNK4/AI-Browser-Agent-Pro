# check_certificate.py — Native SSL/TLS Inspector (Windows)

## What Does This Script Do?

It **inspects the SSL/TLS certificate** of any HTTPS website by driving Chrome's native security popups via **Windows UIAutomation (`pywinauto`)** and snapping full-monitor screenshots using **`mss`**. 

Unlike standard Selenium scripts that capture the HTML viewport, this script captures **Chrome's actual OS-level native dialogs** exactly as a user sees them.

It produces three distinct screenshots per site:
1. **Panel 1** — The Site Information popup (shows when you click the lock icon)
2. **Panel 2** — The Security popup (shows when you click "Connection is secure")
3. **Panel 3** — The Certificate Viewer dialog (shows when you click the certificate)

---

## Important Constraints ⚠️

* **WINDOWS ONLY:** This script rigidly relies on `pywinauto` with the Win32 `uia` backend to interact with Chrome's native UI controls. It will fail on macOS or Linux.
* **HEADED BROWSER REQUIRED:** Windows UIAutomation cannot interact with headless windows because they are not rendered by the Windows Desktop Window Manager (DWM). The `lock` icon physically does not exist to click if the window is hidden.
* **FULL SCREEN CAPTURE:** The script captures the *entire primary monitor* (`sct.monitors[1]`), not just the Chrome window. This guarantees the Windows taskbar and full desktop context are visible as requested for compliance/audit evidence.
* **DO NOT TOUCH MOUSE:** While the script runs, it physically takes control of your mouse to click the native Chrome popups using `SendInput()`. Touching your mouse while the script is running may cause it to miss the popups.

---

## Who Should Use This?

| Use Case | Details |
|---|---|
| SSL/TLS audit evidence | Captures full native Chrome dialogs + full monitor context (taskbar) |
| Compliance screenshots | Shows real lock icon, real URL, real cert fields exactly as rendered by the OS |

---

## Quick Start

```shell
# Install required dependencies
pip install selenium pywinauto mss psutil

# Inspect one site
python check_certificate.py --url https://confluence.opentext.com

# Inspect multiple sites
python check_certificate.py --url https://site1.com --url https://site2.com
```

---

## What Gets Saved

```
tests/certificate/
└── screenshots/
    ├── cert_panel1_confluence_opentext_com_20260303_140000.png   ← Site Info Popup
    ├── cert_panel2_confluence_opentext_com_20260303_140000.png   ← Security Popup
    └── cert_panel3_confluence_opentext_com_20260303_140000.png   ← Certificate Viewer Dialog
```

**Filename format:** `cert_panel{N}_{hostname}_{YYYYMMDD}_{HHMMSS}.png`

---

## How It Works — Step by Step

```
┌──────────────────────────────────────────────────────────────────┐
│  Phase 1: Setup & Window Targeting                               │
│                                                                  │
│  1. Launch Chrome (headed) via Selenium.                         │
│  2. Navigate to URL + Maximize Window dynamically.               │
│  3. Use `psutil` to find the exact Chrome browser PID spawned    │
│     by ChromeDriver.                                             │
│  4. Connect `pywinauto` exclusively to that PID (guarantees we   │
│     don't accidentally script the wrong Chrome window).          │
│                                                                  │
│  Phase 2: UIAutomation & Capture (`mss`)                         │
│                                                                  │
│  5. Force window to OS foreground (ctypes SW_RESTORE / SW_SHOW). │
│  6. Scan UIA Tree for the Lock icon button and click it via      │
│     actual Win32 mouse events (`click_input()`).                 │
│  7. Wait for the `BubbleFrameView` popup (Site Info) to appear.  │
│  8. Capture FULL Primary Monitor via `mss` → Save Panel 1.       │
│  9. Find and click "Connection is secure" inside Panel 1.        │
│ 10. Wait for the next popup.                                     │
│ 11. Capture FULL Primary Monitor via `mss` → Save Panel 2.       │
│ 12. Find and click "Certificate is valid" inside Panel 2.        │
│ 13. Wait for the Certificate Viewer dialog.                      │
│ 14. Capture FULL Primary Monitor via `mss` → Save Panel 3.       │
│                                                                  │
│  Phase 3: Cleanup                                                │
│                                                                  │
│ 15. Send {ESC} 3 times to cleanly close all native dialogs.      │
└──────────────────────────────────────────────────────────────────┘
```

---

## Libraries Used & Why

| Library | Why Used |
|---|---|
| **selenium** | Launches the browser, handles network navigation, and gives us a clean profile every time. |
| **pywinauto** | Connects to the Chrome process via the `uia` backend to traverse the native Windows UI tree. Finds buttons by their accessible names and triggers native mouse clicks. |
| **mss** | Fast cross-platform screenshot library. Used specifically to capture the entire `monitors[1]` screen buffer to ensure the taskbar and desktop are captured. |
| **psutil** | Navigates the process tree from `chromedriver.exe` to find the child `chrome.exe` window, ensuring `pywinauto` attacks the correct window even if the user has 20 other Chrome windows open. |
| **ctypes** (stdlib) | Calls `SetForegroundWindow` and `ShowWindow` directly via `user32.dll` to guarantee the OS respects the window focus request. |

---

## How Does It Find The Lock Icon?

Unlike Selenium which searches the DOM of a webpage, `pywinauto` searches the **Windows OS accessibility tree** (UI Automation or UIA). 

When Chrome's UI is drawn on screen, it exposes its buttons to screen readers (and automation scripts) using specific internal IDs (`AutomationId`). Over the years, Chromium engineers have renamed the lock icon several times:

1. **Older Chrome:** `LocationIconView` or `location-icon-or-bubble`
2. **Mid-era Chrome:** `page-info-button` or `PageInfoChip`
3. **Modern Chrome:** `view-site-information-button` or `security_status_chip_view`

To make the script **version-proof**, it maintains a list of all known historical IDs. If you inspect Chrome using Microsoft's free **Accessibility Insights for Windows** tool, you can see these hidden UIA properties by pointing your mouse at the button. 

If Chrome updates tomorrow and changes the ID again, the script has a resilient **Pass 2 fallback**: it ignores the IDs and scans *all* buttons on the Chrome window until it finds one whose accessible `Name` (what a screen reader says aloud) contains `"view site information"`.
